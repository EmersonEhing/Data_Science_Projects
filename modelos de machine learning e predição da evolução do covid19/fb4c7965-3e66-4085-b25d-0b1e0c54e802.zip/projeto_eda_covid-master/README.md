# projeto_eda_covid
Projeto Digital Innovation One em parceria com o Prof. Dr. Neylson Crepalde

Análise exploratória dos dados do COVID-19 com Python.
